import React, { Component } from 'react';
import { getGridData } from '../api/gridAPI';
import gridJSON from '../assets/grid.json';
import './grid.component.css';

export default class PaymentGridComponent extends Component{
    constructor(props){
        super(props);
        this.state = {
            charges: undefined,
            paymentHistory: undefined,
            openTabs: [],
        };
        this.openDetials = this.openDetials.bind(this);
    }

    componentWillMount(){
        //getGridData();
        this.setState({
            charges: gridJSON[0].charges,
        });
    }

    openDetials(i){
        let openTabs = this.state.openTabs;
        if(openTabs[i] == undefined || openTabs[i] == false){
            openTabs[i] = true;
        }else{
            openTabs[i] = false;
        }        
        this.setState({
            openTabs
        });
        return false;
    }
    render(){
        return(
            <div className="container-fluid grid-container">
                <div className="row">
                    <div className="col-md-12">
                        <h1>Paayment History Grid</h1>
                        <h2>IL10 WS: Get Contract Charges Grid Data</h2>
                        <form className="form-inline">
                            <div className="form-group">
                                <label>Name:&nbsp;&nbsp;</label>
                                <input type="text" className="form-control" id="exampleInputName2" placeholder="#contact"/>
                            </div>                    
                        </form>
                    </div>
                    <div className="col-md-12 grid-table-container">
                    <div className="bg-primary">
                        <h1>PAYMENT HISTORY</h1>
                    </div>
                    <table className="table table-bordered"> 
                        <thead> 
                            <tr className="active"> 
                                <th>See Detials</th> 
                                <th>Charge #</th> 
                                <th>Invoice #</th> 
                                <th>Due Date</th> 
                                <th>Description</th> 
                                <th>Delinquency</th> 
                                <th>Total Invoiced</th> 
                                <th>Cash Reco'd</th> 
                                <th>Manula Adj</th> 
                                <th>Total Due</th> 
                            </tr> 
                        </thead> 
                        
                            {
                                this.state.charges.map((item, index, array)=>{
                                    return (
                                        <tbody>
                                            <tr key={index}>  
                                                <th className="see-details">
                                                    <a href="javascript:void(0)" onClick={()=>this.openDetials(index)}>
                                                    {
                                                        (this.state.openTabs && this.state.openTabs[index] == true)?
                                                        (
                                                            <span className="glyphicon glyphicon-minus"></span>
                                                        ):(
                                                            <span className="glyphicon glyphicon-plus"></span>
                                                        )}
                                                        
                                                    </a>
                                                </th> 
                                                <td>{item.charge}</td> 
                                                <td>{item.invoice}</td> 
                                                <td>{item.duedate}</td> 
                                                <td>{item.description}</td> 
                                                <td>{item.delinquecy}</td>
                                                <td>{item.totalinvoiced}</td> 
                                                <td>{item.cashrecord}</td> 
                                                <td>{item.manualadi}</td>
                                                <td>{item.totaldue}</td>
                                            </tr>
                                            {
                                                (this.state.openTabs && this.state.openTabs[index] == true)?
                                                (
                                                    <tr>
                                                        <td colSpan={10}>
                                                        {
                                                            (item.asspaymenthistories && item.asspaymenthistories.length > 0)?
                                                            (
                                                                    <div>
                                                                        <div className="bg-primary">
                                                                            <h1>Transaction Details</h1>
                                                                        </div>
                                                                        <div className="row tx-box">
                                                                            <div className="col-md-4">
                                                                                <strong>Amount Received:</strong> 7.55
                                                                            </div>
                                                                            <div className="col-md-4">
                                                                            <strong>Date Posted:</strong> 10/31/2017
                                                                            </div>
                                                                            <div className="col-md-4">
                                                                            <strong>Payment Memo:</strong> 
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                            ):''
                                                        }
                                                            
                                                            <div className="bg-primary">
                                                                <h1>Charge List</h1>
                                                            </div>
                                                            <table className="table table-bordered">
                                                                <thead>
                                                                    <tr className="active">
                                                                        <th>Desc</th>
                                                                        <th>Total Invoiced</th>
                                                                        <th>Cash Reco'd</th>
                                                                        <th>Manual Adj</th>
                                                                        <th>Totl Due</th>
                                                                        <th>Date Reco'd</th>
                                                                        <th>Accy Method</th>
                                                                        <th>Misc Charge</th>
                                                                        <th>Tran Number</th>
                                                                        <th>Paayment Memo</th>
                                                                    </tr>
                                                                </thead>
                                                                <TabelRow rows={item.chargelist}></TabelRow>
                                                            </table>
                                                    </td>
                                                    </tr>
                                                ):''
                                            }
                                            
                                        </tbody>
                                    )
                                })
                            } 
                    </table>
                    </div>
                </div>                
            </div>            
        );
    }
}

const TabelRow = (props)=>{    
    let keys = Object.keys(props.rows[0]);
    //console.log(keys);
    return (
        <tbody>
            {
                props.rows.map((item, index, array)=>{
                    return (<TableData keys={keys} item={item}/>)
                })
            } 
        </tbody>       
    );
}

const TableData = (props)=>{
    console.log(props);
    return (<tr>
                {
                    props.keys.map((item, index, array)=>{
                        return (<td>{props.item[item]}</td>)
                    })
                }        
            </tr>);
}