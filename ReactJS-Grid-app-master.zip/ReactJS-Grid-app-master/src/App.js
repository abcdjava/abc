import React, { Component } from 'react';
import GridComponent from './components/grid.component';
import PaymentGridComponent from './components/payment.component';

import './App.css';

class App extends Component {
  constructor(props){
    super(props);
    this.state = {
      active: 'Charges'
    }
    this.navHandler = this.navHandler.bind(this);
  }
  navHandler(name){
    this.setState({
      active: name
    });
  }
  render() {
    return (
      <div>
        <nav className="navbar navbar-default">
          <div className="container-fluid">
          <ul className="nav navbar-nav">
              <li className={(this.state.active == 'Charges')?'active':''}><a href="javascript:void(0)" onClick={()=>this.navHandler('Charges')}>Charges</a></li>
              <li className={(this.state.active == 'Payment History')?'active':''}><a href="javascript:void(0)" onClick={()=>this.navHandler('Payment History')}>Payment History</a></li>
            </ul>
          </div>
        </nav>
        {
          (this.state.active == 'Charges')?(
            <GridComponent></GridComponent>
          ):(
            <PaymentGridComponent></PaymentGridComponent>
          )
        }
        
      </div>
    );
  }
}

export default App;
