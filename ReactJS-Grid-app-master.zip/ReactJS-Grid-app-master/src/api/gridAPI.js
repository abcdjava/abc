export function getGridData(){
    fetch("../assets/grid.json", {
      headers : { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
       }
    })
    .then((response) => response.json())
    .then((messages) => {console.log("messages");});
}